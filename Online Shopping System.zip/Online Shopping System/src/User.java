import java.io.Serializable;

public class User implements Serializable{
    // Instance variables to store user information
    private String username;
    private String password;

    // Constructor to initialize user attributes
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // // Getter method for retrieving the username
    public String getUsername() {
        return this.username;
    }

    // // Setter method for modifying the username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for retrieving the password
    public String getPassword() {
        return this.password;
    }

    // Setter method for modifying the password
    public void setPassword(String password) {
        this.password = password;
    }
}