import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.table.AbstractTableModel;

public class CartTableModel extends AbstractTableModel {
    // Column names for the table
    private String[] columnNames = {"Product", "Quantity", "Price (£)"};
    // Lists to store products, quantities, and prices
    private ArrayList<Product> products;
    private HashMap<Product, Integer> quantity;
    private HashMap<Product, Double> priceList;

    // Constructor to initialize the table model with product details
    public CartTableModel(ArrayList<Product> products, HashMap<Product, Integer> quantity, HashMap<Product, Double> priceList) {
        this.products = products;
        this.quantity = quantity;
        this.priceList = priceList;
    }

    // Get the number of rows in the table
    @Override
    public int getRowCount() {
        return products.size();
    }

    // Get the number of columns in the table
    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    // Get the value at a specific row and column in the table
    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            String productId = products.get(row).getProductId();
            String productName = products.get(row).getProductName();
            if (products.get(row) instanceof Clothing) {
                String size = ((Clothing)products.get(row)).getSize();
                String colour = ((Clothing)products.get(row)).getColour();

                temp = "<html>" + productId + "<br>" + productName + "<br>" + size + ", " + colour + "</html>";
            }
            else if (products.get(row) instanceof Electronics) {
                String brand = ((Electronics)products.get(row)).getBrand();
                String warranty = String.valueOf(((Electronics)products.get(row)).getWarrantyPeriod());

                temp = "<html>" + productId + "<br>" + productName + "<br>" + brand + ", " + warranty + "</html>";
            }
        }
        else if (col == 1) {
            for (Product key : quantity.keySet()) {
                if (key.getProductId().equals(products.get(row).getProductId())) {
                    temp = quantity.get(key);
                }
            }
        }
        else if (col == 2) {
            for (Product key : priceList.keySet()) {
                if (key.getProductId().equals(products.get(row).getProductId())) {
                    temp = priceList.get(key);
                }
            }
        }
        return temp;
    }

    // Get the name of a specific column
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }
}