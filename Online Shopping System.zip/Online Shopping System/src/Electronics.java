// Electronics class extends the Product class, representing a specific type of product
public class Electronics extends Product {
    // Additional Instance variables specific to electronics products
    private String brand;
    private String warrantyPeriod;

    // Constructor to initialize electronics product with provided values
    public Electronics(String productId, String productName, int numberOfAvailableItems, double price, String brand, String warrantyPeriod) {
        // Call the constructor of the superclass to initialize common attributes
        super(productId, productName, numberOfAvailableItems, price);
        // Initialize specific attributes for electronics
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }

    // Getter method for retrieving the brand
    public String getBrand() {
        return this.brand;
    }

    // Setter method for modifying the brand
    public void setBrand(String brand) {
        this.brand = brand;
    }

    // Getter method for retrieving the warrantyPeriod
    public String getWarrantyPeriod() {
        return this.warrantyPeriod;
    }

    // Setter method for modifying the warrantyPeriod
    public void setWarrantyPeriod(String warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }
}