import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ProductTableModel<T extends Product> extends AbstractTableModel {
    // Column names for the table
    private final String[] columnNames = {"Product ID", "Name", "Category", "Price (£)", "Info"};
    // List of products to display in the table
    private final ArrayList<T> products;
    // Constructor to initialize the table model with a list of products
    public ProductTableModel(ArrayList<T> products) {
        this.products = products;
    }

    // Get the number of columns in the table
    @Override
    public int getColumnCount() {
        return this.columnNames.length;
    }

    // Get the number of rows in the table
    @Override
    public int getRowCount() {
        return this.products.size();
    }

    // Get the value at a specific row and column in the table
    @Override
    public Object getValueAt(int row, int col) {
        Object temp = null;
        if (col == 0) {
            temp = products.get(row).getProductId();
        }
        else if (col == 1) {
            temp = products.get(row).getProductName();
        }
        else if (col == 2) {
            if (products.get(row) instanceof Electronics) {
                temp = "Electronics";
            }
            else if (products.get(row) instanceof Clothing) {
                temp = "Clothing";
            }
        }
        else if (col == 3) {
            temp = products.get(row).getPrice();
        }
        else if (col == 4) {
            if (products.get(row) instanceof Electronics) {
                temp = ((Electronics)products.get(row)).getBrand() + ", " + ((Electronics)products.get(row)).getWarrantyPeriod();
            }
            else if (products.get(row) instanceof Clothing) {
                temp = ((Clothing)products.get(row)).getSize() + ", " + ((Clothing)products.get(row)).getColour();
            }
        }
        return temp;
    }

    // Get the name of a specific column
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }
}