import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingCart {
    // List to store products in the shopping cart
    private final ArrayList<Product> cartProducts;
    // HashMap to store the quantity of each product in the cart
    private final HashMap<Product , Integer> quantityOfEach;
    // HashMap to store the total price for each product based on quantity
    private final HashMap<Product, Double> quantityPriceList;

    // Constructor to initialize the shopping cart
    public ShoppingCart() {
        cartProducts = new ArrayList<Product>();
        quantityOfEach = new HashMap<Product, Integer>();
        quantityPriceList = new HashMap<Product, Double>();
    }

    // Getter method to retrieve the list of products in the cart
    public ArrayList<Product> getCartProducts() {
        return this.cartProducts;
    }

    // Getter method to retrieve the quantity of each product in the cart
    public HashMap<Product, Integer> getQuantityOfEach() {
        return this.quantityOfEach;
    }

    // Getter method to retrieve the total price for each product based on quantity
    public HashMap<Product, Double> getQuantityPriceList() {
        return this.quantityPriceList;
    }

    // Method to add a product to the cart
    public void addToCart(Product product) {
        cartProducts.add(product);
    }

    // Method to add a specific quantity of a product to the cart
    public void addProductQuantity(Product product, int quantity) {
        quantityOfEach.put(product, quantity);
        updateQuantityPrice(product, quantity);
    }

    // Helper method to update the total price for a product based on quantity
    private void updateQuantityPrice(Product product, int quantity) {
        quantityPriceList.put(product, (product.getPrice() * quantity));
    }

    // Method to remove a product from the cart
    public void removeProduct(Product removeProduct) {
        for (Product product : cartProducts) {
            if (product.getProductId().equals(removeProduct.getProductId())) {
                cartProducts.remove(product);
                break;
            }
        }
        for (Product key : quantityOfEach.keySet()) {
            if (key.getProductId().equals(removeProduct.getProductId())) {
                quantityOfEach.remove(key);
            }
        }
        for (Product key : quantityPriceList.keySet()) {
            if (key.getProductId().equals(removeProduct.getProductId())) {
                quantityPriceList.remove(key);
            }
        }
    }

    // Method to remove the quantity of a specific product from the cart
    public void removeProductQuantity(Product removeProduct) {
        quantityOfEach.remove(removeProduct);
    }

    // Method to calculate the total cost of all products in the cart
    public double calculateTotal() {
        double totalCost = 0;
        for (Product key : quantityOfEach.keySet()) {
            totalCost = totalCost + (key.getPrice() * 100 * quantityOfEach.get(key));
        }
        return totalCost / 100;
    }

    // Method to check if a specific product is already in the cart
    public boolean isAlreadyInTheCart(Product checkProduct) {
        for (Product product : cartProducts) {
            if (product.getProductId().equals(checkProduct.getProductId())) {
                return true;
            }
        }
        return false;
    }
}