import java.io.Serializable;

// Abstract class representing a generic product
public abstract class Product implements Serializable {
    // Instance variables to store product information
    private String productId;
    private String productName;
    private int numberOfAvailableItems;
    private double price;

    // Constructor to initialize product attributes
    public Product(String productId, String productName, int numberOfAvailableItems, double price) {
        this.productId = productId;
        this.productName = productName;
        this.numberOfAvailableItems = numberOfAvailableItems;
        this.price = price;
    }

    // Getter method for retrieving the product ID
    public String getProductId() {
        return this.productId;
    }

    // Setter method for modifying the product ID
    public void setProductId(String productId) {
        this.productId = productId;
    }

    // Getter method for retrieving the product name
    public String getProductName() {
        return this.productName;
    }

    // Setter method for modifying the product name
    public void setProductName(String productName) {
        this.productName = productName;
    }

    // Getter method for retrieving the number of available items
    public int getNumberOfAvailableItems() {
        return this.numberOfAvailableItems;
    }

    // Setter method for modifying the number of available items
    public void setNumberOfAvailableItems(int numberOfAvailableItems) {
        this.numberOfAvailableItems = numberOfAvailableItems;
    }

    // Getter method for retrieving the product price
    public double getPrice() {
        return this.price;
    }

    // Setter method for modifying the product price
    public void setPrice(double price) {
        this.price = price;
    }
}