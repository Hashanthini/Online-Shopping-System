import java.io.*;
import java.util.ArrayList;

public class AccountManager {
    // File name to store user credentials
    private static final String fileName = "UserCredentials.txt";

    // Creates a new user account with the given username and password
    public static void createUserAccount(String username, String password) {
        // Retrieve existing user accounts from file
        ArrayList<User> userList = readUserAccounts();

        // Add the new user to the list
        userList.add(new User(username, password));

        // Save the updated user accounts to file
        saveUserAccounts(userList);
    }

    // Reads the list of user accounts from the file
    @SuppressWarnings("unchecked")
    private static ArrayList<User> readUserAccounts() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(fileName))) {
            return (ArrayList<User>)input.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            return new ArrayList<>();
        }
    }

    // Saves the list of user accounts to the file
    private static void saveUserAccounts(ArrayList<User> userList) {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName))) {
            output.writeObject(userList);
        } catch (IOException e) {
            System.out.println("Some error occurs in the saveUserAccounts method.");
        }
    }

    // Retrieves a user object by searching for the given username
    public static User getUserByUsername(String username) {
        ArrayList<User> userList = readUserAccounts();
        return userList.stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }
}