public interface ShoppingManager {

}