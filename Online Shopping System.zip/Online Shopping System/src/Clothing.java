// Clothing class extends the Product class, representing a specific type of product
public class Clothing extends Product {
    // Additional Instance variables specific to clothing products
    private String size;
    private String colour;

    // Constructor to initialize clothing product with provided values
    public Clothing(String productId, String productName, int numberOfAvailableItems, double price, String size, String colour) {
        // Call the constructor of the superclass to initialize common attributes
        super(productId, productName, numberOfAvailableItems, price);
        // Initialize specific attributes for clothing
        this.size = size;
        this.colour = colour;
    }

    // Getter method for retrieving the size
    public String getSize() {
        return this.size;
    }

    // Setter method for modifying the size
    public void setSize(String size) {
        this.size = size;
    }

    // Getter method for retrieving the colour
    public String getColour() {
        return this.colour;
    }

    // Setter method for modifying the colour
    public void setColour(String colour) {
        this.colour = colour;
    }
}