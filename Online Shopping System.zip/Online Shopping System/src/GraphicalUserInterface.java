import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.border.Border;
import javax.swing.table.JTableHeader;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// Class representing the Graphical User Interface for the shopping application
public class GraphicalUserInterface extends JFrame {
    private static JComboBox<String> options;
    private final JPanel p1;
    private JScrollPane scrollPane;
    private final JTable table = new JTable();
    private final tableSelectionHandler tableEventHandler = new tableSelectionHandler();
    private final JButton addShoppingCart = new JButton("Add to Shopping Cart");
    private final JPanel p4 = new JPanel(new GridLayout(8, 1, 0, 6));
    private final JPanel p5 = new JPanel(new FlowLayout(FlowLayout.CENTER));
    private final JPanel p6 = new JPanel(new BorderLayout());
    private boolean isElectronicsSorted = false;
    private boolean isClothingSorted = false;
    private boolean isAllSorted = false;
    private static int requiredIndex;
    private static Product requiredObject;
    private ListSelectionEvent listEvent;
    private JDialog dialog;
    private double totalPrice;
    private double firstPurchasePrice;
    private double threeSamePrice;
    private double finalTotalPrice;

    // Constructor for the GUI
    public GraphicalUserInterface() {
        setTitle("Westminster Shopping Centre");
        setSize(1100, 800);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        p1 = new JPanel();
        p1.setLayout(new BorderLayout());

        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton button1 = new JButton("Shopping Cart");
        button1.setToolTipText("Click to see the product details in the shopping cart.");
        Insets shopMargin = new Insets(8, 0, 8, 0);
        button1.setMargin(shopMargin);
        button1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button1.addActionListener(new CartButtonHandler());
        p2.add(button1);
        p1.add(p2, BorderLayout.NORTH);

        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.CENTER));
        JLabel selectCategoryLabel = new JLabel("Select Product Category: ");
        p3.add(selectCategoryLabel);
        options = new JComboBox<String>(new String[]{"All", "Electronics", "Clothing"});
        ComboEventHandler eventHandler = new ComboEventHandler();
        options.addActionListener(eventHandler);
        p3.add(options);

        JButton sortButton = new JButton("Sort Table");
        sortButton.setToolTipText("Click to sort the table according to product id.");
        Insets sortMargin = new Insets(8, 0, 8, 0);
        sortButton.setMargin(sortMargin);
        sortButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        SortButtonEventHandler sortEventHandler = new SortButtonEventHandler();
        sortButton.addActionListener(sortEventHandler);
        p1.add(sortButton, BorderLayout.WEST);
        p1.add(p3, BorderLayout.CENTER);

        getContentPane().add(p1, BorderLayout.NORTH);

        Insets addShopping = new Insets(8, 0, 8, 0);
        addShoppingCart.setMargin(addShopping);
        p5.add(addShoppingCart);
        addShoppingCart.setToolTipText("Click to add the selected product to the shopping cart.");
        addShoppingCart.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addShoppingCart.addActionListener(new AddShoppingCartHandler());

        if (Objects.equals(options.getSelectedItem(), "All")) {
            ProductTableModel<Product> tableModel = new ProductTableModel<Product>(readAllProducts());
            table.setModel(tableModel);
            centerAlignCellContent(table);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            table.getSelectionModel().addListSelectionListener(tableEventHandler);
            table.setGridColor(Color.BLACK);
            scrollPane = new JScrollPane(table);
            scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
            scrollPane.setOpaque(false);
            p1.add(scrollPane, BorderLayout.SOUTH);
            table.setRowHeight(25);
            styleColumnHeading(table, Font.BOLD);
        }
    }

    // Helper method to center-align cell content in the table
    public void centerAlignCellContent(JTable table) {
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(new dataCellRenderer());
        }
    }

    // Renderer class for customizing cell rendering in the table
    private static class dataCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(JLabel.CENTER);
            Border matteBorder = BorderFactory.createMatteBorder(0, 1, 0, 0, Color.BLACK);
            Border emptyBorder = BorderFactory.createEmptyBorder(10, 5, 10, 5);
            Border compoundBorder = BorderFactory.createCompoundBorder(matteBorder, emptyBorder);
            setBorder(compoundBorder);
            return component;
        }
    }

    // Helper method to style column headings in the table
    public void styleColumnHeading(JTable table, int fontStyle) {
        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer(new HeaderStyleRenderer(fontStyle));
    }

    // Renderer class for customizing header rendering in the table
    private static class HeaderStyleRenderer extends DefaultTableCellRenderer {
        private final int fontStyle;

        public HeaderStyleRenderer(int fontStyle) {
            this.fontStyle = fontStyle;
            setHorizontalAlignment(JLabel.CENTER);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            Font font = component.getFont().deriveFont(fontStyle);
            component.setFont(font);
            Border matteBorder = BorderFactory.createMatteBorder(2, 1, 1, 1, Color.BLACK);
            Border emptyBorder = BorderFactory.createEmptyBorder(10, 5, 10, 5);
            Border compoundBorder = BorderFactory.createCompoundBorder(matteBorder, emptyBorder);
            setBorder(compoundBorder);
            return component;
        }
    }

    // Event handler for product category selection
    private class ComboEventHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            isElectronicsSorted = false;
            isClothingSorted = false;
            isAllSorted = false;

            scrollPane.getViewport().removeAll();
            p4.removeAll();
            p5.removeAll();
            p6.removeAll();
            if (Objects.equals(options.getSelectedItem(), "Electronics")) {
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Electronics> tableModel = new ProductTableModel<Electronics>(readElectronicsProducts());
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            } else if (Objects.equals(options.getSelectedItem(), "Clothing")) {
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Clothing> tableModel = new ProductTableModel<Clothing>(readClothingProducts());
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            } else if (Objects.equals(options.getSelectedItem(), "All")) {
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Product> tableModel = new ProductTableModel<Product>(readAllProducts());
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            }
            p1.revalidate();
            p1.repaint();
        }
    }

    // Event handler for the "Sort Table" button
    private class SortButtonEventHandler implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            isElectronicsSorted = false;
            isClothingSorted = false;
            isAllSorted = false;

            scrollPane.getViewport().removeAll();
            p4.removeAll();
            p5.removeAll();
            p6.removeAll();
            if (Objects.equals(options.getSelectedItem(), "All")) {
                isAllSorted = true;
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Product> tableModel = new ProductTableModel<Product>(sortFunction(readAllProducts()));
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            } else if (Objects.equals(options.getSelectedItem(), "Electronics")) {
                isElectronicsSorted = true;
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Electronics> tableModel = new ProductTableModel<Electronics>(sortFunction(readElectronicsProducts()));
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            } else if (Objects.equals(options.getSelectedItem(), "Clothing")) {
                isClothingSorted = true;
                table.getSelectionModel().removeListSelectionListener(tableEventHandler);
                ProductTableModel<Clothing> tableModel = new ProductTableModel<Clothing>(sortFunction(readClothingProducts()));
                table.setModel(tableModel);
                centerAlignCellContent(table);
                table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                table.getSelectionModel().addListSelectionListener(tableEventHandler);
                table.setGridColor(Color.BLACK);
                scrollPane.setViewportView(table);
            }
            p1.revalidate();
            p1.repaint();
        }
    }

    // Event handler for table selection changes
    private class tableSelectionHandler implements ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent event) {
            listEvent = event;
            p4.removeAll();
            p5.removeAll();
            p6.removeAll();
            if (!event.getValueIsAdjusting() && (table.getSelectionModel().getSelectedItemsCount() == 1)) {
                if (Objects.equals(options.getSelectedItem(), "Electronics")) {
                    int selectionIndex = table.getSelectionModel().getAnchorSelectionIndex();
                    Electronics electronics;
                    if (isElectronicsSorted) {
                        electronics = sortFunction(readElectronicsProducts()).get(selectionIndex);

                    } else {
                        electronics = readElectronicsProducts().get(selectionIndex);
                    }
                    detailsWhenSelect(electronics);
                    p5.add(addShoppingCart);
                } else if (Objects.equals(options.getSelectedItem(), "Clothing")) {
                    int selectionIndex = table.getSelectionModel().getAnchorSelectionIndex();
                    Clothing clothing;
                    if (isClothingSorted) {
                        clothing = sortFunction(readClothingProducts()).get(selectionIndex);
                    } else {
                        clothing = readClothingProducts().get(selectionIndex);
                    }
                    detailsWhenSelect(clothing);
                    p5.add(addShoppingCart);
                } else if (Objects.equals(options.getSelectedItem(), "All")) {
                    int selectionIndex = table.getSelectionModel().getAnchorSelectionIndex();
                    Product all;
                    if (isAllSorted) {
                        all = sortFunction(readAllProducts()).get(selectionIndex);
                    } else {
                        all = readAllProducts().get(selectionIndex);
                    }
                    detailsWhenSelect(all);
                    p5.add(addShoppingCart);
                }

                requiredIndex = table.getSelectionModel().getAnchorSelectionIndex();
                if (isAllSorted) {
                    requiredObject = sortFunction(readAllProducts()).get(requiredIndex);
                } else if (isElectronicsSorted) {
                    requiredObject = sortFunction(readElectronicsProducts()).get(requiredIndex);
                } else if (isClothingSorted) {
                    requiredObject = sortFunction(readClothingProducts()).get(requiredIndex);
                } else if (Objects.equals(options.getSelectedItem(), "All")) {
                    requiredObject = readAllProducts().get(requiredIndex);
                } else if (Objects.equals(options.getSelectedItem(), "Electronics")) {
                    requiredObject = readElectronicsProducts().get(requiredIndex);
                } else if (Objects.equals(options.getSelectedItem(), "Clothing")) {
                    requiredObject = readClothingProducts().get(requiredIndex);
                }

                p6.add(p4, BorderLayout.CENTER);
                p6.add(p5, BorderLayout.SOUTH);

                getContentPane().add(p6, BorderLayout.CENTER);

                p6.revalidate();
                p6.repaint();
            }
        }
    }

    // Method to display product details when selected in the table
    public void detailsWhenSelect(Product product) {
        JLabel emptyLabel = new JLabel("");
        p4.add(emptyLabel);
        JLabel selectProductLabel = new JLabel("            \t\tSelected Product - " + product.getProductName());
        Font productTitleFont = new Font("Arial", Font.BOLD, 14);
        selectProductLabel.setFont(productTitleFont);
        p4.add(selectProductLabel);
        JLabel productIdLabel = new JLabel("            \t\tProduct Id: " + product.getProductId());
        p4.add(productIdLabel);
        JLabel categoryLabel = new JLabel("            \t\tCategory: " + "Electronics");
        p4.add(categoryLabel);
        JLabel nameLabel = new JLabel("            \t\tName: " + product.getProductName());
        p4.add(nameLabel);
        if (product instanceof Electronics) {
            JLabel brandLabel = new JLabel("            \t\tBrand: " + ((Electronics) product).getBrand());
            p4.add(brandLabel);
            JLabel warrantyLabel = new JLabel("            \t\tWarranty: " + ((Electronics) product).getWarrantyPeriod());
            p4.add(warrantyLabel);
        } else if (product instanceof Clothing) {
            JLabel sizeLabel = new JLabel("            \t\tSize: " + ((Clothing) product).getSize());
            p4.add(sizeLabel);
            JLabel colourLabel = new JLabel("            \t\tColour: " + ((Clothing) product).getColour());
            p4.add(colourLabel);
        }
        JLabel itemsAvailable = new JLabel("            \t\tItems Available: " + product.getNumberOfAvailableItems());
        p4.add(itemsAvailable);
    }

    // Method to perform sorting of the product list
    public <T extends Product> ArrayList<T> sortFunction(ArrayList<T> productList) {
        ArrayList<String> productId = new ArrayList<String>();
        ArrayList<T> sortedList = new ArrayList<T>();
        for (T product : productList) {
            productId.add(product.getProductId());
        }
        Collections.sort(productId);
        for (String id : productId) {
            for (T product : productList) {
                if (product.getProductId().equals(id)) {
                    sortedList.add(product);
                    break;
                }
            }
        }
        return sortedList;
    }

    // Methods to read product data from file based on category
    @SuppressWarnings("unchecked")
    public static ArrayList<Product> readAllProducts() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("details_byte.txt"))) {
            return (ArrayList<Product>) input.readObject();
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Electronics> readElectronicsProducts() {
        ArrayList<Electronics> electronics = new ArrayList<Electronics>();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("details_byte.txt"))) {
            for (Product product : (ArrayList<Product>) input.readObject()) {
                if (product instanceof Electronics) {
                    electronics.add((Electronics) product);
                }
            }
            return electronics;
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Clothing> readClothingProducts() {
        ArrayList<Clothing> clothing = new ArrayList<Clothing>();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("details_byte.txt"))) {
            for (Product product : (ArrayList<Product>) input.readObject()) {
                if (product instanceof Clothing) {
                    clothing.add((Clothing) product);
                }
            }
            return clothing;
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }

    // Method to add selected item to the shopping cart
    public void addSelectedItem(Product requiredObject) {
        if (LoginOrSignup.shoppingCart != null) {
            if (!LoginOrSignup.shoppingCart.isAlreadyInTheCart(requiredObject)) {
                LoginOrSignup.shoppingCart.addToCart(requiredObject);
                LoginOrSignup.shoppingCart.addProductQuantity(requiredObject, 1);
            } else {
                System.out.println("Product already in the shopping cart.");
            }
        } else {
            System.out.println("Shopping cart object is null");
        }
    }

    // Event handler for the "Shopping Cart" button
    public class CartButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            if (dialog != null && dialog.isShowing()) {
                dialog.dispose();
                shoppingCartGui();
            }
            else {
                shoppingCartGui();
            }
        }
    }

    // Event handler for the "Add to Shopping Cart" button
    public class AddShoppingCartHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            addSelectedItem(requiredObject);
            if (dialog != null && dialog.isShowing()) {
                dialog.dispose();
                if (LoginOrSignup.mode.equals("NonAccountHolder")) {
                    shoppingCartGui();
                }
                else if (LoginOrSignup.mode.equals("AccountHolder")) {
                    System.out.println(LoginOrSignup.currentUsername);
                    LoginOrSignup.allUserHistory.get(LoginOrSignup.currentUsername).add(requiredObject);
                    System.out.println(1);
                    shoppingCartGui();
                }
            }
        }
    }

    // Method to display the shopping cart GUI
    public void shoppingCartGui() {
        dialog = new JDialog();
        dialog.setTitle("Shopping Cart");
        dialog.setSize(1000, 700);
        dialog.setLayout(new BorderLayout());

        JPanel nestedNorth = new JPanel(new BorderLayout());

        JPanel threeButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton removeButton = new JButton("Remove");
        JButton increaseButton = new JButton("Increase Quantity");
        JButton decreaseButton = new JButton("Decrease Quantity");
        threeButtons.add(removeButton);
        threeButtons.add(increaseButton);
        threeButtons.add(decreaseButton);
        nestedNorth.add(threeButtons, BorderLayout.NORTH);

        CartTableModel model = new CartTableModel(LoginOrSignup.shoppingCart.getCartProducts(), LoginOrSignup.shoppingCart.getQuantityOfEach(), LoginOrSignup.shoppingCart.getQuantityPriceList());
        JTable shoppingCartTable = new JTable(model);
        shoppingCartTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane shoppingCartScrollPane = new JScrollPane(shoppingCartTable);
        shoppingCartTable.setRowHeight(60);
        shoppingCartTable.setGridColor(Color.BLACK);
        styleColumnHeading(shoppingCartTable, Font.BOLD);
        centerAlignCellContent(shoppingCartTable);
        shoppingCartScrollPane.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        shoppingCartScrollPane.setOpaque(false);
        nestedNorth.add(shoppingCartScrollPane, BorderLayout.CENTER);
        dialog.getContentPane().add(nestedNorth, BorderLayout.NORTH);

        getCenterContainer(LoginOrSignup.mode);

        JPanel westContainer = new JPanel(new GridLayout(4, 2));

        westContainer.add(new JLabel(""));
        JPanel westOne = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        westOne.add(new JLabel("Total ->"));
        westContainer.add(westOne);
        westContainer.add(new JLabel(""));
        JPanel westTwo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        westTwo.add(new JLabel("First Purchase Discount (10%) ->"));
        westContainer.add(westTwo);
        westContainer.add(new JLabel(""));
        JPanel westThree = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        westThree.add(new JLabel("Three items in same Category Discount (20%) ->"));
        westContainer.add(westThree);
        westContainer.add(new JLabel(""));
        JPanel westFour = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        Font font = new Font("Sans Serif", Font.BOLD, 15);
        JLabel finalTotalLabel = new JLabel("Final Total ->");
        finalTotalLabel.setFont(font);
        westFour.add(finalTotalLabel);
        westContainer.add(westFour);

        dialog.getContentPane().add(westContainer, BorderLayout.WEST);

        JPanel confirm = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton confirmButton = new JButton("Confirm Purchase");
        confirmButton.addActionListener(new ConfirmButtonHandler());
        confirm.add(confirmButton);

        dialog.getContentPane().add(confirm, BorderLayout.SOUTH);

        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }

    // Event handler for the "Confirm Purchase" button
    public class ConfirmButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            dialog.dispose();
            updateWithPrevious();
            saveUserHistory();
            thankYouGui();
        }
    }

    // Method to display a thank you message
    public void thankYouGui() {
        JDialog thankYouDialog = new JDialog();
        thankYouDialog.setTitle("Westminster online shopping");
        thankYouDialog.setSize(300, 150);
        thankYouDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel text = new JLabel("Thank you for the purchase");
        Font font = new Font("Arial", Font.BOLD, 20);
        text.setFont(font);
        text.setHorizontalAlignment(JLabel.CENTER);
        thankYouDialog.getContentPane().add(text);
        thankYouDialog.setLocationRelativeTo(null);
        thankYouDialog.setVisible(true);
    }

    public double calculateProductsTotal() {
        totalPrice = LoginOrSignup.shoppingCart.calculateTotal();
        return totalPrice;
    }

    public double threeSameCategoryDiscount() {
        if (!LoginOrSignup.shoppingCart.getCartProducts().isEmpty() || (LoginOrSignup.shoppingCart.getCartProducts().size() < 3)) {
            int electronicsCount = 0;
            int clothingCount = 0;
            for (Product product : LoginOrSignup.shoppingCart.getCartProducts()) {
                if (product instanceof Electronics) {
                    electronicsCount++;
                }
                else if (product instanceof Clothing) {
                    clothingCount++;
                }
            }
            if (electronicsCount >= 3 || clothingCount >= 3) {
                double discountAmount = calculateProductsTotal() * 100 * 2;
                String before = String.valueOf(discountAmount/1000);
                String formattedValue = before.substring(0, before.length() - 1);
                threeSamePrice = Double.parseDouble(formattedValue);
                return threeSamePrice;
            }
        }
        return threeSamePrice;
    }

    public double firstPurchaseDiscount() {
        int equalCount = 0;
        ArrayList<Product> historyDetailsOfCurrent = LoginOrSignup.allUserHistory.get(LoginOrSignup.currentUsername);
        for (Product product : LoginOrSignup.shoppingCart.getCartProducts()) {
            for (Product historyProduct : historyDetailsOfCurrent) {
                if (product.getProductId().equals(historyProduct.getProductId())) {
                    equalCount++;
                }
            }
        }
        if (LoginOrSignup.shoppingCart.getCartProducts().size() == equalCount) {
            firstPurchasePrice = 0;
        }
        else if (LoginOrSignup.shoppingCart.getCartProducts().size() > equalCount) {
            double discountAmount = calculateProductsTotal() * 100 * 1;
            String before = String.valueOf(discountAmount/1000);
            String formattedValue = before.substring(0, before.length() - 1);
            firstPurchasePrice = Double.parseDouble(formattedValue);
        }
        return firstPurchasePrice;
    }

    public double finalTotalCalculation(String mode) {
        if (!LoginOrSignup.shoppingCart.getCartProducts().isEmpty() && mode.equals("NonAccountHolder")) {
            finalTotalPrice = totalPrice;
            return finalTotalPrice;
        }
        else if (!LoginOrSignup.shoppingCart.getCartProducts().isEmpty() && mode.equals("AccountHolder")) {
            double beforeTotal = (totalPrice * 100) - (firstPurchasePrice * 100) - (threeSamePrice * 100);
            finalTotalPrice = beforeTotal/100;
            return finalTotalPrice;
        }
        return finalTotalPrice;
    }

    // Method to update user history with previous purchases
    public void updateWithPrevious() {
        if (!LoginOrSignup.shoppingCart.getCartProducts().isEmpty()) {
            for (Product product : LoginOrSignup.shoppingCart.getCartProducts()) {
                LoginOrSignup.allUserHistory.get(LoginOrSignup.currentUsername).add(product);
            }
        }
    }

    // Method to save user history to file
    public static void saveUserHistory() {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("UserHistory.txt"))) {
            output.writeObject(LoginOrSignup.allUserHistory);
        } catch (IOException e) {
            System.out.println("saveUserHistoryFails");
        }
    }

    // Method to retrieve user history from fil
    @SuppressWarnings("unchecked")
    public static HashMap<String, ArrayList<Product>> retrieveUserHistory() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("UserHistory.txt"))) {
            return (HashMap<String, ArrayList<Product>>)input.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("retrieveUserHistoryFails");
            return new HashMap<>();
        }
    }

    // Method to display the central container in the shopping cart GUI
    public void getCenterContainer(String mode) {
        JPanel centerContainer = new JPanel(new GridLayout(4, 2));
        JPanel centerOne = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerOne.add(new JLabel(calculateProductsTotal() + " £"));
        centerContainer.add(centerOne);
        centerContainer.add(new JLabel(""));
        JPanel centerTwo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerTwo.add(new JLabel(mode.equals("NonAccountHolder") ? "- Not applicable -" : firstPurchaseDiscount() + " £"));
        centerContainer.add(centerTwo);
        centerContainer.add(new JLabel(""));
        JPanel centerThree = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerThree.add(new JLabel(mode.equals("NonAccountHolder") ? "- Not applicable -" : threeSameCategoryDiscount() + " £"));
        centerContainer.add(centerThree);
        centerContainer.add(new JLabel(""));
        JPanel centerFour = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel finalTotal = new JLabel(finalTotalCalculation(mode) + " £");
        finalTotal.setFont(new Font("Sans Serif", Font.BOLD, 15));
        centerFour.add(finalTotal);
        centerContainer.add(centerFour);
        centerContainer.add(new JLabel(""));

        dialog.getContentPane().add(centerContainer, BorderLayout.CENTER);
    }
}