import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class UserHistory {
    // List to store the history of product names
    private final ArrayList<String> productsNameHistory;
    // Constructor to initialize the product name history list
    public UserHistory() {
        productsNameHistory = new ArrayList<String>();
    }
    // Method to add a product to the user's history
    public void addProducts(Product product) {
        this.productsNameHistory.add(product.getProductName());
    }
    // Method to retrieve the history of product names
    public ArrayList<String> getProductsNameHistory() {
        return this.productsNameHistory;
    }
}